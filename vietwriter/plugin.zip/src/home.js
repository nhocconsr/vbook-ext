function execute() {
    return Response.success([
        {title: "Cập Nhật", input: "https://vietwriter.vn/whats-new/posts/1911868", script: "gen.js"},
        {title: "Ngôn Tình", input: "https://vietwriter.vn/truyen-ngon-tinh", script: "gen.js"},
        {title: "Truyện Việt", input: "https://vietwriter.vn/truyen-viet", script: "gen.js"},
    ]);
}