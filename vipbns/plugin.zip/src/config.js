let BASE_URL = "https://ngocsach.com";
let BASE_HOST = "https://bachngocsach.vip";
try {
    if (CONFIG_URL) {
        BASE_URL = CONFIG_URL;
    }
} catch (error) {
}