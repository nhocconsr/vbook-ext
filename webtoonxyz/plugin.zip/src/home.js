function execute() {
    return Response.success([
        {title: "Cập nhật", input: "https://www.webtoon.xyz/webtoons", script: "gen.js"},
    ]);
}