function execute(key, page) {
    if (!page) page = '1';
    const doc = Http.get('https://m.truyencv.vn').params({q:key,page: page}).html();

    var next = doc.select(".pagination").select("li.active + li").text()

    const el = doc.select(".css-1x5zbq0")

    const data = [];
    for (var i = 0; i < el.size(); i++) {
        var e = el.get(i);
        data.push({
            name: e.select("h3").first().text(),
            link: e.select("a").first().attr("href"),
            cover: e.select("img").first().attr("data-src"),
            description: null , 
            host: "https://m.truyencv.vn",
        })
    }

    return Response.success(next)
}