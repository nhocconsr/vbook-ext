function execute() {
 return Response.success([
    {title: "Truyện Hot", input: "https://m.truyencv.vn/truyen-hot", script: "gen.js"},
    {title: "Truyện mới", input: "https://m.truyencv.vn/truyen-moi", script: "gen.js"},
    {title: "Truyện Full", input: "https://m.truyencv.vn/truyen-full", script: "gen.js"},
 ]);
}