function execute(url) {
    let response = fetch(url);
    if (response.ok) {
    //var doc = Http.get(url).html();
    let doc = response.html();
    var el = doc.select(".css-aklayb .listing ul li a")
    const data = [];
    for (var i = el.size() - 1; i >= 0; i--) {
        var e = el.get(i);
        data.push({
            name: e.select(".title").text(),
            url: "https://m.truyencv.vn" + e.attr("href"),
            host: "https://m.truyencv.vn"
        })
    }

    return Response.success(data);
}}