function execute() {
    return Response.success([
        { title: "Last Update", input: "https://fastmanhwa.net/", script: "gen.js" },
    ]);
}