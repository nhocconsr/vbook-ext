function execute() {
    return Response.success([
        {
            "input": "/the-loai/3d",
            "title": "3D",
            "script": "cat.js"
        },
        {
            "input": "/the-loai/adult",
            "title": "Adult",
            "script": "cat.js"
        },
        {
            "input": "/the-loai/animal-girl",
            "title": "Animal girl",
            "script": "cat.js"
        },
        {
            "input": "/the-loai/artist",
            "title": "Artist",
            "script": "cat.js"
        },
        {
            "input": "/the-loai/bao-dam",
            "title": "Bạo Dâm",
            "script": "cat.js"
        },
        {
            "input": "/the-loai/cg",
            "title": "CG",
            "script": "cat.js"
        },
        {
            "input": "/the-loai/choi-hai-lo",
            "title": "Chơi Hai Lỗ",
            "script": "cat.js"
        },
        {
            "input": "/the-loai/complete",
            "title": "Complete",
            "script": "cat.js"
        },
        {
            "input": "/the-loai/con-trung",
            "title": "Côn Trùng",
            "script": "cat.js"
        },
        {
            "input": "/the-loai/cosplay",
            "title": "Cosplay",
            "script": "cat.js"
        },
        {
            "input": "/the-loai/doujinshi",
            "title": "Doujinshi",
            "script": "cat.js"
        },
        {
            "input": "/the-loai/do-boi",
            "title": "Đồ Bơi",
            "script": "cat.js"
        },
        {
            "input": "/the-loai/ecchi",
            "title": "Ecchi",
            "script": "cat.js"
        },
        {
            "input": "/the-loai/elf",
            "title": "Elf",
            "script": "cat.js"
        },
        {
            "input": "/the-loai/fantasy",
            "title": "Fantasy",
            "script": "cat.js"
        },
        {
            "input": "/the-loai/furry",
            "title": "Furry",
            "script": "cat.js"
        },
        {
            "input": "/the-loai/futanari",
            "title": "Futanari",
            "script": "cat.js"
        },
        {
            "input": "/the-loai/gangbang",
            "title": "Gangbang",
            "script": "cat.js"
        },
        {
            "input": "/the-loai/gender-bender",
            "title": "Gender Bender",
            "script": "cat.js"
        },
        {
            "input": "/the-loai/giao-vien",
            "title": "Giáo Viên",
            "script": "cat.js"
        },
        {
            "input": "/the-loai/group",
            "title": "Group",
            "script": "cat.js"
        },
        {
            "input": "/the-loai/guro",
            "title": "Guro",
            "script": "cat.js"
        },
        {
            "input": "/the-loai/hai-huoc",
            "title": "Hài Hước",
            "script": "cat.js"
        },
        {
            "input": "/the-loai/ham-hiep",
            "title": "Hãm Hiếp",
            "script": "cat.js"
        },
        {
            "input": "/the-loai/harem",
            "title": "Harem",
            "script": "cat.js"
        },
        {
            "input": "/the-loai/hau-gai",
            "title": "Hầu Gái",
            "script": "cat.js"
        },
        {
            "input": "/the-loai/hau-mon",
            "title": "Hậu Môn",
            "script": "cat.js"
        },
        {
            "input": "/the-loai/housewife",
            "title": "Housewife",
            "script": "cat.js"
        },
        {
            "input": "/the-loai/kinh-di",
            "title": "Kinh Dị",
            "script": "cat.js"
        },
        {
            "input": "/the-loai/kogal",
            "title": "Kogal",
            "script": "cat.js"
        },
        {
            "input": "/the-loai/lang-man",
            "title": "Lãng Mạn",
            "script": "cat.js"
        },
        {
            "input": "/the-loai/lao-gia-dam",
            "title": "Lão Gìa Dâm",
            "script": "cat.js"
        },
        {
            "input": "/the-loai/loan-luan",
            "title": "Loạn Luân",
            "script": "cat.js"
        },
        {
            "input": "/the-loai/loli",
            "title": "Loli",
            "script": "cat.js"
        },
        {
            "input": "/the-loai/lxhentai",
            "title": "LXHENTAI",
            "script": "cat.js"
        },
        {
            "input": "/the-loai/mang-thai",
            "title": "Mang Thai",
            "script": "cat.js"
        },
        {
            "input": "/the-loai/manhwa",
            "title": "Manhwa",
            "script": "cat.js"
        },
        {
            "input": "/the-loai/mat-kinh",
            "title": "Mắt Kính",
            "script": "cat.js"
        },
        {
            "input": "/the-loai/mature",
            "title": "Mature",
            "script": "cat.js"
        },
        {
            "input": "/the-loai/milf",
            "title": "Milf",
            "script": "cat.js"
        },
        {
            "input": "/the-loai/mind-break",
            "title": "Mind Break",
            "script": "cat.js"
        },
        {
            "input": "/the-loai/mind-control",
            "title": "Mind Control",
            "script": "cat.js"
        },
        {
            "input": "/the-loai/monster-girl",
            "title": "Monster Girl",
            "script": "cat.js"
        },
        {
            "input": "/the-loai/nguc-lon",
            "title": "Ngực Lớn",
            "script": "cat.js"
        },
        {
            "input": "/the-loai/nguc-nho",
            "title": "Ngực Nhỏ",
            "script": "cat.js"
        },
        {
            "input": "/the-loai/no-le",
            "title": "Nô Lệ",
            "script": "cat.js"
        },
        {
            "input": "/the-loai/ntr",
            "title": "NTR",
            "script": "cat.js"
        },
        {
            "input": "/the-loai/nu-sinh",
            "title": "Nữ Sinh",
            "script": "cat.js"
        },
        {
            "input": "/the-loai/oneshot",
            "title": "OneShot",
            "script": "cat.js"
        },
        {
            "input": "/the-loai/quai-vat",
            "title": "Quái Vật",
            "script": "cat.js"
        },
        {
            "input": "/the-loai/scat",
            "title": "Scat",
            "script": "cat.js"
        },
        {
            "input": "/the-loai/series",
            "title": "Series",
            "script": "cat.js"
        },
        {
            "input": "/the-loai/shota",
            "title": "Shota",
            "script": "cat.js"
        },
        {
            "input": "/the-loai/supernatural",
            "title": "Supernatural",
            "script": "cat.js"
        },
        {
            "input": "/the-loai/the-thao",
            "title": "Thể Thao",
            "script": "cat.js"
        },
        {
            "input": "/the-loai/thu-vat",
            "title": "Thú Vật",
            "script": "cat.js"
        },
        {
            "input": "/the-loai/trap",
            "title": "Trap",
            "script": "cat.js"
        },
        {
            "input": "/the-loai/truyen-comic",
            "title": "Truyện Comic",
            "script": "cat.js"
        },
        {
            "input": "/the-loai/truyen-khong-che",
            "title": "Truyện Không Che",
            "script": "cat.js"
        },
        {
            "input": "/the-loai/truyen-mau",
            "title": "Truyện Màu",
            "script": "cat.js"
        },
        {
            "input": "/the-loai/truyen-ngan",
            "title": "Truyện Ngắn",
            "script": "cat.js"
        },
        {
            "input": "/the-loai/virgin",
            "title": "Virgin",
            "script": "cat.js"
        },
        {
            "input": "/the-loai/xuc-tua",
            "title": "Xúc Tua",
            "script": "cat.js"
        },
        {
            "input": "/the-loai/y-ta",
            "title": "Y Tá",
            "script": "cat.js"
        },
        {
            "input": "/the-loai/yaoi",
            "title": "Yaoi",
            "script": "cat.js"
        },
        {
            "input": "/the-loai/yuri",
            "title": "Yuri",
            "script": "cat.js"
        }
    ]);
}