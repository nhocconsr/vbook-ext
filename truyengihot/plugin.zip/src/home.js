function execute() {
    return Response.success([
        { title: "Cập Nhật", input: "", script: "gen.js" },
        { title: "#Boys' Love", input: "296", script: "source.js" },
        { title: "#Girl's Love", input: "297", script: "source.js" },
    ]);
}