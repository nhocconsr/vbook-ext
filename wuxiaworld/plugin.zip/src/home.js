function execute() {
    return Response.success([
        {title: "Home", input: "https://www.wuxiaworld.com/api/novels/search", script: "gen.js"},
    ]);
}