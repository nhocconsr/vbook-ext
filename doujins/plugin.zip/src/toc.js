function execute(url) {
    return Response.success([{
        name: 'One Shot',
        url: url,
        host: "https://doujins.com"
    }]);
}