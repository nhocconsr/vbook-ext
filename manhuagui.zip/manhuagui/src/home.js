function execute() {
    return Response.success([
        {title: "最新更新", input: "lianzai/update", script: "gen.js"},
    ]);
}