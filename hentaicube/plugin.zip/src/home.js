function execute() {
    return Response.success([
        {title: "Cập nhật", input: "https://hentaicb.top", script: "gen.js"},
    ]);
}