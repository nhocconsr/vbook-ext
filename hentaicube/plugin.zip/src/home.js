function execute() {
    return Response.success([
        {title: "Cập nhật", input: "https://hentaicb.xyz", script: "gen.js"},
    ]);
}