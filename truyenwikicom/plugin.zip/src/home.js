function execute() {
    return Response.success([
        {title: "Home", input: "https://truyenwiki.com/tim-kiem", script: "gen.js"},
    ]);
}