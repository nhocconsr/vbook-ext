function execute() {
    return Response.success([
        {title: "Home", input: "https://truyenwiki1.com/tim-kiem", script: "gen.js"},
    ]);
}