function execute() {
    return Response.success([
        {title: "Nam Sinh", input: "https://hotruyen.com/nam-sinh", script: "gen.js"}
    ]);
}