let BASE_URL = 'https://sayhentai.fun';
try {
    if (CONFIG_URL) {
        BASE_URL = CONFIG_URL;
    }
} catch (error) {
}