function execute() {
    return Response.success([
        {
            "input": "/tim-truyen/action",
            "title": "Action",
            "script": "gen.js"
        },
        {
            "input": "/tim-truyen/truong-thanh",
            "title": "Adult",
            "script": "gen.js"
        },
        {
            "input": "/tim-truyen/phieu-luu",
            "title": "Adventure",
            "script": "gen.js"
        },
        {
            "input": "/tim-truyen/anime",
            "title": "Anime",
            "script": "gen.js"
        },
        {
            "input": "/tim-truyen/chuyen-sinh",
            "title": "Chuyển Sinh",
            "script": "gen.js"
        },
        {
            "input": "/tim-truyen/comedy",
            "title": "Comedy",
            "script": "gen.js"
        },
        {
            "input": "/tim-truyen/nau-an",
            "title": "Cooking",
            "script": "gen.js"
        },
        {
            "input": "/tim-truyen/comic",
            "title": "Comic",
            "script": "gen.js"
        },
        {
            "input": "/tim-truyen/co-dai",
            "title": "Cổ Đại",
            "script": "gen.js"
        },
        {
            "input": "/tim-truyen/drama",
            "title": "Drama",
            "script": "gen.js"
        },
        {
            "input": "/tim-truyen/dam-my",
            "title": "Đam Mỹ",
            "script": "gen.js"
        },
        {
            "input": "/tim-truyen/ecchi",
            "title": "Ecchi",
            "script": "gen.js"
        },
        {
            "input": "/tim-truyen/fantasy",
            "title": "Fantasy",
            "script": "gen.js"
        },
        {
            "input": "/tim-truyen/harem",
            "title": "Harem",
            "script": "gen.js"
        },
        {
            "input": "/tim-truyen/historical",
            "title": "Historical",
            "script": "gen.js"
        },
        {
            "input": "/tim-truyen/horror",
            "title": "Horror",
            "script": "gen.js"
        },
        {
            "input": "/tim-truyen/live-action",
            "title": "Live action",
            "script": "gen.js"
        },
        {
            "input": "/tim-truyen/manga",
            "title": "Manga",
            "script": "gen.js"
        },
        {
            "input": "/tim-truyen/manhua",
            "title": "Manhua",
            "script": "gen.js"
        },
        {
            "input": "/tim-truyen/manhwa",
            "title": "Manhwa",
            "script": "gen.js"
        },
        {
            "input": "/tim-truyen/martial-arts",
            "title": "Martial Arts",
            "script": "gen.js"
        },
        {
            "input": "/tim-truyen/mature",
            "title": "Mature",
            "script": "gen.js"
        },
        {
            "input": "/tim-truyen/mystery",
            "title": "Mystery",
            "script": "gen.js"
        },
        {
            "input": "/tim-truyen/mecha",
            "title": "Mecha",
            "script": "gen.js"
        },
        {
            "input": "/tim-truyen/ngon-tinh",
            "title": "Ngôn Tình",
            "script": "gen.js"
        },
        {
            "input": "/tim-truyen/one-shot",
            "title": "One shot",
            "script": "gen.js"
        },
        {
            "input": "/tim-truyen/psychological",
            "title": "Psychological",
            "script": "gen.js"
        },
        {
            "input": "/tim-truyen/romance",
            "title": "Romance",
            "script": "gen.js"
        },
        {
            "input": "/tim-truyen/school-life",
            "title": "School Life",
            "script": "gen.js"
        },
        {
            "input": "/tim-truyen/shoujo",
            "title": "Shoujo",
            "script": "gen.js"
        },
        {
            "input": "/tim-truyen/shoujo-ai",
            "title": "Shoujo Ai",
            "script": "gen.js"
        },
        {
            "input": "/tim-truyen/shounen",
            "title": "Shounen",
            "script": "gen.js"
        },
        {
            "input": "/tim-truyen/slice-of-life",
            "title": "Slice of Life",
            "script": "gen.js"
        },
        {
            "input": "/tim-truyen/seinen",
            "title": "Seinen",
            "script": "gen.js"
        },
        {
            "input": "/tim-truyen/smut",
            "title": "Smut",
            "script": "gen.js"
        },
        {
            "input": "/tim-truyen/sci-fi",
            "title": "Sci-fi",
            "script": "gen.js"
        },
        {
            "input": "/tim-truyen/soft-yaoi",
            "title": "Soft Yaoi",
            "script": "gen.js"
        },
        {
            "input": "/tim-truyen/ntr",
            "title": "NTR",
            "script": "gen.js"
        },
        {
            "input": "/tim-truyen/soft-yuri",
            "title": "Soft Yuri",
            "script": "gen.js"
        },
        {
            "input": "/tim-truyen/sports",
            "title": "Sports",
            "script": "gen.js"
        },
        {
            "input": "/tim-truyen/supernatural",
            "title": "Supernatural",
            "script": "gen.js"
        },
        {
            "input": "/tim-truyen/josei",
            "title": "Josei",
            "script": "gen.js"
        },
        {
            "input": "/tim-truyen/thieu-nhi",
            "title": "Thiếu Nhi",
            "script": "gen.js"
        },
        {
            "input": "/tim-truyen/trinh-tham",
            "title": "Trinh Thám",
            "script": "gen.js"
        },
        {
            "input": "/tim-truyen/truyen-mau",
            "title": "Truyện Màu",
            "script": "gen.js"
        },
        {
            "input": "/tim-truyen/tragedy",
            "title": "Tragedy",
            "script": "gen.js"
        },
        {
            "input": "/tim-truyen/webtoon",
            "title": "Webtoon",
            "script": "gen.js"
        },
        {
            "input": "/tim-truyen/xuyen-khong",
            "title": "Xuyên Không",
            "script": "gen.js"
        },
        {
            "input": "/tim-truyen/gender-bender",
            "title": "Gender Bender",
            "script": "gen.js"
        },
        {
            "input": "/tim-truyen/16",
            "title": "16+",
            "script": "gen.js"
        },
        {
            "input": "/tim-truyen/18",
            "title": "18+",
            "script": "gen.js"
        }
    ]);
}