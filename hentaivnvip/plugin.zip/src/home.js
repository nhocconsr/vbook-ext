function execute() {
    return Response.success([
        {title: "Cập Nhật", input: "https://hentaivn.vip/truyen-hentai-moi", script: "gen.js"},
        {title: "Hot Tuần", input: "https://hentaivn.vip/truyen-hot/truyen-hot-tuan", script: "gen.js"},
        {title: "Full Color", input: "https://hentaivn.vip/the-loai/full-color", script: "gen.js"},
        {title: "Không Che", input: "https://hentaivn.vip/the-loai/khong-che", script: "gen.js"},
    ]);
}