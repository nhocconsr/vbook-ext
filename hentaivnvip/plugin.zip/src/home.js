function execute() {
    return Response.success([
        {title: "Cập Nhật", input: "https://hentaivnvip.com/truyen-hentai-moi", script: "gen.js"},
        {title: "Hot Tuần", input: "https://hentaivnvip.com/truyen-hot", script: "gen.js"},
        {title: "Full Color", input: "https://hentaivnvip.com/the-loai/full-color", script: "gen.js"},
        {title: "Không Che", input: "https://hentaivnvip.com/the-loai/khong-che", script: "gen.js"},
    ]);
}