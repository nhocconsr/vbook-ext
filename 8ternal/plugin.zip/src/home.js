function execute() {
    return Response.success([
        {title: "Đọc truyện", input: "https://comic.8ternal.com.vn/series.html", script: "gen.js"},
    ]);
}